
#include "heaviside_tiling.h"
#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"
#include <iostream>


namespace optiling {
static ge::graphStatus TilingFunc(gert::TilingContext* context)
{

  HeavisideTilingData tiling;
  uint32_t size = context->GetInputTensor(0)->GetShapeSize();
  
  auto ascendcPlatform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
  uint32_t aivNum = ascendcPlatform.GetCoreNumAiv();

  auto dt = context->GetInputTensor(0)->GetDataType(); //  ge::DT_FLOAT
  int DataTypeSize=0;

  if(dt==ge::DT_FLOAT){
    DataTypeSize=4;
  }else{
    DataTypeSize=2;
  }
  //会越界吗 GM到底可以越界多少？
  uint32_t blockSize=(size*DataTypeSize+511)/512;
  aivNum=std::min(aivNum,blockSize);
//   uint32_t n_block_per_core=blockSize/aivNum;
//512B对齐
  uint32_t smallSize=blockSize/aivNum*512/DataTypeSize;
  uint16_t incSize=512/DataTypeSize;
  uint16_t formerNum=blockSize%aivNum;


  tiling.set_smallSize(smallSize);
  tiling.set_incSize(incSize);
  tiling.set_formerNum(formerNum);

  context->SetBlockDim(aivNum);
  tiling.SaveToBuffer(context->GetRawTilingData()->GetData(), context->GetRawTilingData()->GetCapacity());
  context->GetRawTilingData()->SetDataSize(tiling.GetDataSize());

    
   // std::cerr << "blockSize: " << blockSize << std::endl;
   // std::cerr << "aivNum: " << aivNum << std::endl;
   // std::cerr << "smallSize: " << smallSize << std::endl;
   // std::cerr << "incSize: " << incSize << std::endl;
   // std::cerr << "formerNum: " << formerNum << std::endl;
    
  return ge::GRAPH_SUCCESS;
}
}


namespace ge {
static ge::graphStatus InferShape(gert::InferShapeContext* context)
{
    const gert::Shape* x1_shape = context->GetInputShape(0);
    gert::Shape* y_shape = context->GetOutputShape(0);
    *y_shape = *x1_shape;
    return GRAPH_SUCCESS;
}
}


namespace ops {
class Heaviside : public OpDef {
public:
    explicit Heaviside(const char* name) : OpDef(name)
    {
        this->Input("input")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("values")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("out")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND})
            .UnknownShapeFormat({ge::FORMAT_ND, ge::FORMAT_ND});

        this->SetInferShape(ge::InferShape);

        this->AICore()
            .SetTiling(optiling::TilingFunc);
        this->AICore().AddConfig("ascend910b");

    }
};

OP_ADD(Heaviside);
}
