#define K_MAX_SHAPE_DIM 0

#include "kernel_operator.h"
using namespace AscendC;

constexpr uint32_t BufferNum=1;
class KernelHeaviside {
public:
    __aicore__ inline KernelHeaviside() {}
   __aicore__ inline void Init(GM_ADDR input, GM_ADDR values, GM_ADDR out,uint32_t smallSize,uint16_t incSize,uint16_t formerNum
    ,TPipe* pipeIn
)
    {   
        pipe = pipeIn;
        uint32_t beginIndex=0;
        if (GetBlockIdx() < formerNum) {
            this->size=smallSize+incSize;
            beginIndex=size*GetBlockIdx();
        }else{
            this->size=smallSize;
            beginIndex=size*GetBlockIdx()+formerNum*incSize;
        }


        inputGm.SetGlobalBuffer((__gm__ DTYPE_INPUT *)input+beginIndex ,size);
        valuesGm.SetGlobalBuffer((__gm__ DTYPE_VALUES *)values+beginIndex,size);
        outGm.SetGlobalBuffer((__gm__ DTYPE_OUT *)out+beginIndex,size);
        pipe->InitBuffer(inQueueInput, BufferNum, size*sizeof(DTYPE_VALUES));
        pipe->InitBuffer(inQueueValues, BufferNum, size*sizeof(DTYPE_VALUES));
        pipe->InitBuffer(selMaskQueue, BufferNum, size);
        pipe->InitBuffer(outQueueY, BufferNum, size*sizeof(DTYPE_VALUES));

    }
    __aicore__ inline void Process()
    {
        LocalTensor<DTYPE_INPUT> inputLocal = inQueueInput.AllocTensor<DTYPE_INPUT>();
        LocalTensor<DTYPE_INPUT> valuesLocal = inQueueValues.AllocTensor<DTYPE_VALUES>();
        LocalTensor<uint8_t> selMaskLocal = selMaskQueue.AllocTensor<uint8_t>();

        DataCopy(inputLocal,inputGm,size);
        inQueueInput.EnQue<DTYPE_INPUT>(inputLocal);
        inputLocal = inQueueInput.DeQue<DTYPE_INPUT>();

        DataCopy(valuesLocal,valuesGm,size);
        inQueueValues.EnQue<DTYPE_VALUES>(valuesLocal);
        valuesLocal = inQueueValues.DeQue<DTYPE_VALUES>();

        LocalTensor<DTYPE_INPUT> outLocal = outQueueY.AllocTensor<DTYPE_VALUES>();

        //等于0，从valuesLocal取,否则从1取
        CompareScalar(selMaskLocal, inputLocal, static_cast<DTYPE_VALUES>(0.0), CMPMODE::EQ, size);
        Select(valuesLocal, selMaskLocal, valuesLocal, (DTYPE_VALUES)1.0, SELMODE::VSEL_TENSOR_SCALAR_MODE, size);
        //大于等于0，从valuesLocal取，否则从0取
        CompareScalar(selMaskLocal, inputLocal, static_cast<DTYPE_VALUES>(0.0), CMPMODE::GE, size);
        Select(outLocal, selMaskLocal, valuesLocal, (DTYPE_VALUES)0.0, SELMODE::VSEL_TENSOR_SCALAR_MODE, size);

        inQueueInput.FreeTensor<DTYPE_INPUT>(inputLocal);
        inQueueValues.FreeTensor<DTYPE_INPUT>(valuesLocal);
        selMaskQueue.FreeTensor<uint8_t>(selMaskLocal);

        outQueueY.EnQue<DTYPE_VALUES>(outLocal);
        outLocal = outQueueY.DeQue<DTYPE_VALUES>();
        DataCopy(outGm,outLocal,size);
        outQueueY.FreeTensor<DTYPE_INPUT>(outLocal);


    }


private:
    TPipe *pipe;
    GlobalTensor<DTYPE_INPUT> inputGm;
    GlobalTensor<DTYPE_VALUES> valuesGm;
    GlobalTensor<DTYPE_OUT> outGm;
    TQue<QuePosition::VECIN, BufferNum> inQueueInput;
    TQue<QuePosition::VECIN, BufferNum> inQueueValues;
    TQue<QuePosition::VECOUT, BufferNum> outQueueY;
    TQue<QuePosition::VECCALC, BufferNum> selMaskQueue;

    uint32_t size;

};
extern "C" __global__ __aicore__ void heaviside(GM_ADDR input, GM_ADDR values, GM_ADDR out, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    // TODO: user kernel impl
    TPipe pipe;
    KernelHeaviside op;
     op.Init(input,values,out,tiling_data.smallSize,tiling_data.incSize,tiling_data.formerNum,&pipe);
    op.Process();
}